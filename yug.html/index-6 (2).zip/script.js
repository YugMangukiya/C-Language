document.addEventListener('DOMContentLoaded',() =>
{
    const addform = document.getElementById('Addform');
    const Editform = document.getElementById('Editform');
    const StudentTable = document.querySelector('.Student-form');


let Students =[];

let EditIndex = -1;

addform.addEventListener('submit',(e) => {
    e.preventDefault();
    const newStudent = {
        Name:addform.StudentAddName.value,
        Age:addform.StudentAddAge.value,
        MobileNo:addform.StudentAddPhoneNO.value,
        Address:addform.StudentAddAddress.value,
    };
    Students.push(newStudent)
    addform.reset()
    renderTable();
})


Editform.addEventListener('submit',(e) => {
    e.preventDefault();
    const updateStudent = {
        Name:Editform.StudentEditName.value,
        Age:Editform.StudentEditAge.value,
        PhoneNo:Editform.StudentEditPhoneNo.value,
        Address:Editform.StudentEditAddress.value,
    };
    Students[EditIndex] = updateStudent;
    EditIndex = -1
    Editform.reset()
    renderTable()
})

  const renderTable = () => {
    const tableHTML = `
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Age</th>
                    <th>PhoneNo</th>
                    <th>Address</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                ${Students.map((Student , index) => `
                <tr>
                    <td>${Student.Name}</td>
                    <td>${Student.Age}</td>
                    <td>${Student.PhoneNo}</td>
                    <td>${Student.Address}</td>
                    <td>
                        <button onclick='editStudent(${index})'>Edit</button>
                        <button onclick='deleteStudent(${index})'>Delete</button>
                    </td>
                </tr>
                `).join('')}
            </tbody>           
        </table>
    `;
    StudentTable.innerHTML = tableHTML;
}

window.EditStudent =(index) => {
    EditIndex = index;
    const Student = Student[index];
    Editform.StudentEditName.value = Student.Name
    Editform.StudentEditAge.value = Student.Age
    Editform.StudentEditPhoneNo.value = Student.PhoneNo
    Editform.StudentEditAddress.value = Student.Address
}

window.deleteStudent = (index) => {
    Students.splice(index , 1);
    renderTable();
}

})
